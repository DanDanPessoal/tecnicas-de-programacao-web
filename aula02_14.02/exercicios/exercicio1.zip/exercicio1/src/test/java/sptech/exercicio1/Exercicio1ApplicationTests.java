package sptech.exercicio1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
